SARAH-Plugin-sysinfo
====================
Version 1.00002

Auteur: Ferreira Agostinho
Demandeur:Gui Arnaud
Dec 2013

Bonjour
=====================

Le Plugin Sysinfo et une version Béta a tester sans modération.

j'ai corrigé le bug du disk.vbs, non utilisé.

Je vais encore apporter quelque modification dans le code du sysinfo.js, pour qu'il soie plus visible et mieux codé.

Bug Corriger
=====================
La taille de la mémoire utilisé
L'url des fichiers et géré par le fichier .js

Amélioration prévu dans le futur 
=====================
Un seul fichier .vbs qui génére un fichier JSON de l'état de la machine.

Amicalement votre
Mr Ferreira

